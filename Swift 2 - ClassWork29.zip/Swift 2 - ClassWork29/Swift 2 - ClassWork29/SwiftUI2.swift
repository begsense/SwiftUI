//___FILEHEADER___

import SwiftUI

@main
struct SwiftUI2: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
