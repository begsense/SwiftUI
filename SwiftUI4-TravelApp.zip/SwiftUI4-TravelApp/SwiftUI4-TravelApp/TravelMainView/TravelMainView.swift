//
//  TravelMainView.swift
//  SwiftUI4-TravelApp
//
//  Created by M1 on 29.05.2024.
//

import SwiftUI


struct TravelMainView: View {
    
    @StateObject var viewModel: TravelMainViewModel
    @State private var showAlert = false
    @State private var randomTip: Tip?
    
    var body: some View {
        NavigationStack {
            VStack {
                ScrollView {
                    
                    ForEach(0..<viewModel.destinations.count, id: \.self) { index in
                        
                        NavigationLink(value: index) {
                            ZStack {
                                AsyncImage(url: URL(string: viewModel.destinations[index].poster))
                                    .frame(height: 200)
                                    .scaledToFit()
                                    .cornerRadius(35)
                                VStack {
                                    Spacer()
                                    
                                    Text(viewModel.destinations[index].title)
                                    
                                    Spacer(minLength: 10)
                                    
                                    Text(viewModel.destinations[index].shortdescription)
                                        .frame(width: 200, height: 150)
                                    
                                }
                                .foregroundColor(.white)
                                .shadow(color: .black, radius: 22)
                            }
                        }
                        .padding(5)
                    }
                }
                .navigationDestination(for: Int.self) { number in
                    TravelDetailView(selectedDestination: viewModel.destinations[number])
                    
                }
                
                Spacer()
                
                Button(action: {
                    randomTip = viewModel.randomTip()
                    showAlert = true
                }) {
                    Text("Travel Tips")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .alert(item: $randomTip) { tip in
                    Alert(title: Text("სამოგზაურო რჩევა"), message: Text(tip.text), dismissButton: .default(Text("კაი ჩემო ძმაო!")))
                }
            }
            .padding()
            .background(Color(red: 18/255, green: 25/255, blue: 33/255))
            .navigationTitle("Voyager-ი კაი აჟერი")
        }
        .onAppear {
            viewModel.fetchDestinations()
        }
    }
}

#Preview {
    TravelMainView(viewModel: TravelMainViewModel())
}
