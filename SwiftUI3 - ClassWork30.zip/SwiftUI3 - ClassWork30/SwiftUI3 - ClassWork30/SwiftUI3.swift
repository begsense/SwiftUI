
import SwiftUI

@main
struct SwiftUI3: App {
    var body: some Scene {
        WindowGroup {
            StoreView()
        }
    }
}
